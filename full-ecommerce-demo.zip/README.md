# Full Ecommerce Demo Application

## Frontend
React Application with:
- Home Page
- Products Page
- About Page
- Contact Page

## Backend
Spring Boot REST API

## Run Backend

cd backend-springboot
mvn spring-boot:run

Backend URL:
http://localhost:8080/products

## Run Frontend

cd frontend-react
npm install
npm start

Frontend URL:
http://localhost:3000